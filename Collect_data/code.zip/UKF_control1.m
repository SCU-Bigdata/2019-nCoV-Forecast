function   [Xk_UKF_plus,Cov_UKF_plus,Qk_es,x_error,sigma]=UKF_control1(Xk_UKF_minus,Cov_UKF_minus,Zk,Rk,Qk,tspan,pop,m,state_error)
%Unscented Kalman filter
dim_x=8;dim_y=3;N=dim_x;num_s=(2*N+1);
%% Set selection of Sigma Points
Xk_minus=zeros(dim_x,num_s);
Xk_minus_a=Xk_UKF_minus;
Xk_minus(:,N+1)=Xk_minus_a;
W0=0.1;
W=((1-W0)/(2*N))*ones(1,num_s); W(1,N+1)=W0;
temp_s0=chol(N/(1-W(1,N+1))*Cov_UKF_minus);
temp_s=temp_s0';
for j=1:N
    Xk_minus(:,j)=Xk_minus_a-temp_s(:,j);
    Xk_minus(:,j+N+1)=Xk_minus_a+temp_s(:,j);
end
%% Time update
Xk_plus_fj=zeros(dim_x,num_s);
Xk_plus_f=zeros(dim_x,1); Zk_minus_f=zeros(dim_y,1);
for j=1:num_s
xt0 = Xk_minus(1:8,j);
f = @(t,seir) [m*seir(5)*(pop-seir(1)-seir(2)-seir(3)-seir(4))*seir(1)/pop - seir(6)*seir(1); seir(6)*seir(1)-(seir(7)+seir(8))*seir(2);seir(7)*seir(2);seir(8)*seir(2);0;0;0;0];
[~,value] = ode45(f,tspan,xt0);
Xk_plus_fj(:,j)=value(end,:)'+state_error;
Xk_plus_f= Xk_plus_f+W(j)*Xk_plus_fj(:,j);
end
H=[0 1 1 1 0 0 0 0;0 0 1 0 0 0 0 0;0 0 0 1 0 0 0 0];
Zk_minus_fj=H*Xk_plus_fj;
for j=1:num_s
Zk_minus_f=Zk_minus_f+W(j)*Zk_minus_fj(:,j);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Pk_plus_f=Qk;Cov_Zk_minus_f=Rk;
Cov_Xk_Zk_minus_f=zeros(dim_x,dim_y);
for j=1:num_s
Pk_plus_f=Pk_plus_f+W(j)*(Xk_plus_fj(:,j)-Xk_plus_f)*(Xk_plus_fj(:,j)-Xk_plus_f)';

Cov_Zk_minus_f=Cov_Zk_minus_f+W(j)*(Zk_minus_fj(:,j)-Zk_minus_f)*(Zk_minus_fj(:,j)-Zk_minus_f)';
Cov_Xk_Zk_minus_f=Cov_Xk_Zk_minus_f+W(j)*(Xk_plus_fj(:,j)-Xk_plus_f)*(Zk_minus_fj(:,j)-Zk_minus_f)';
end
Cov_Zk_minus_f=(Cov_Zk_minus_f+Cov_Zk_minus_f')/2;
Pk_plus_f=(Pk_plus_f+Pk_plus_f')/2;
%% Measurement update
Kk=Cov_Xk_Zk_minus_f*inv(Cov_Zk_minus_f);
z_error=Zk-Zk_minus_f;
error=Kk*z_error;
Xk_plus=Xk_plus_f+error;
Pk_plus=Pk_plus_f-Kk*Cov_Zk_minus_f*Kk';
Xk_UKF_plus=[round(Xk_plus(1:4));Xk_plus(5:8)];
ind=Xk_UKF_plus(3:4)-Xk_UKF_minus(3:4);
ind_b=find(ind<0);
Xk_UKF_plus(ind_b+2,:)=Xk_UKF_minus(ind_b+2,:);
err1=sum(Xk_UKF_plus(2:4),1)-sum(Xk_UKF_minus(2:4),1);
if err1<0
Xk_UKF_plus(2)=Xk_UKF_plus(2)-err1;
end
err2=sum(Xk_UKF_plus(1:4),1)-sum(Xk_UKF_minus(1:4),1);
if err2<0
Xk_UKF_plus(1)=Xk_UKF_plus(1)-err2+round((Zk(1)-(sum(Xk_UKF_minus(2:4),1)))*abs(rand(1))/100);
end
Cov_UKF_plus=Pk_plus;
t=(Xk_UKF_plus(5)/Xk_UKF_minus(5));
if t>1.2
  Xk_UKF_plus(5)=Xk_UKF_minus(5);
end    
if Xk_UKF_plus(5)<0
    Xk_UKF_plus(5)=0.01;
end
if Xk_UKF_plus(6)<1/30
    Xk_UKF_plus(6)=1/30;
end
x_error=Xk_UKF_plus-Xk_plus_f;
Qk_es=(x_error-state_error)*(x_error-state_error)';
Rk_es=(z_error)*(z_error)';
%% R_0 sigma points
Xk_plus=zeros(dim_x,num_s);
Xk_plus(:,N+1)=Xk_UKF_plus;
W0=0.1;
W=((1-W0)/(2*N))*ones(1,num_s); W(1,N+1)=W0;
temp_s00=chol(N/(1-W(1,N+1))*Cov_UKF_plus);
temp_s1=temp_s00';
for j=1:N
    Xk_plus(:,j)=Xk_UKF_plus-temp_s1(:,j);
    Xk_plus(:,j+N+1)=Xk_UKF_plus+temp_s1(:,j);
end
R=[Xk_plus(5,:)./Xk_plus(7,:)];
sigma=std(R);
end

