clear all
clc
close all
%% read data
[cum_confirm,text1] = xlsread('Data_countries.xlsx', 'Cumulative confirme infections');
[cum_recovry,text2] = xlsread('Data_countries.xlsx', 'Cumulative death cases');
[cum_death,text3] = xlsread('Data_countries.xlsx', 'Cumulative recovery cases');
[m,n]=size(cum_confirm);
data_all=zeros(m,n,3);
data_all(:,:,1)=cum_confirm;
data_all(:,:,2)=cum_recovry;
data_all(:,:,3)=cum_death;
num=size(cum_confirm,1);
for j=num %GEC
rng(j,'v5normal')
data_test=[data_all(j,1:end,1);data_all(j,1:end,2);data_all(j,1:end,3)];
index=find(data_test(1,:)~=0);
data_test=data_test(:,index);
initial_date=datetime(2020,1,20)+index(1)-1;
a_nextincub=find(sum(abs(diff(data_test')),2)~=0)+1;
remove_same_data=30;
ind=a_nextincub(find(a_nextincub>remove_same_data))';
if isempty(ind)
    eff_index=[1:length(data_test)];
else
eff_index=[1:ind(1)-1,ind];
end
data_test1=data_test(:,eff_index(1:end));
Xk1=data_test1;
%% Compute the population size for pathogen transmission
sigma_r=1*[1 1 1]';
t=1;% 
m=1;
R=diag(sigma_r).^2;%measurement noise covariance
if j==num %GEC
    Q=diag([4e4 1e3 4e2 1e2 1e-8 1e-8 1e-8 1e-8]);% 
    xk_ini=[10*data_test(1,1);data_test(:,1);0.1;0.1;0.1;0.001];
    cons=10;
    span=30;  
    time=60;
    Pop_selection1=1.5e8:1e7:3e8;
%%%%%%%%%% Compute the population size for pathogen transmission %%%%%%%%%%
    for kkk=length(Xk1)
    day=7;
    [N0,~,~]  = J_days2(xk_ini,Xk1(:,1:kkk),Q,R,Pop_selection1,day,eff_index(:,1:end),time); 
    end
%       N0=224000000; %The population size for pathogen transmission of GEC derived by the selection criterion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%% Nowcasting and Forecating--SEIRC model
x_ini=xk_ini;
for mmm=length(Xk1)
Xk=Xk1(:,1:mmm);
K1=size(Xk,2);
Zk_sensor=Xk;
last=500;
pre_day=7;% Days of predition
if j==num %GEC
Q=diag([4e3 1e3 1e3 1e2 10000*eps 5000*eps 10000*eps 10000*eps]);
end
RMSE_UKF_smooth2=cell(K1-2,1);
new_increase_error_smooth2=cell(K1-2,1);
R0_smooth2=zeros(1,K1-1);
std_R0=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
Xk_UKF_plus_store_smooth2=zeros(9,last);
Xk_UKF_plus_store_smooth2(:,1)=[N0-sum(x_ini(1:4));x_ini];
Qk=zeros(8,8,K1);
Qk(:,:,1)=Q;
mean_Q=Q;
state_error=zeros(8,K1);
mean_s_e=state_error(:,1);
Pk_UKF_plus=cons*Q;
pop1=N0;
Xk_UKF_plus=x_ini;
for k=1:K1-1
    m_es=1;
    [Xk_UKF_plus,Pk_UKF_plus,Q1,s_e,sigma_R]=UKF_control1(Xk_UKF_plus,Pk_UKF_plus,Zk_sensor(:,k+1),R,Q,[eff_index(k):1/10:eff_index(k+1)],pop1,m_es,mean_s_e);
    std_R0=[std_R0,sigma_R];
    Qk(:,:,k+1)=Q1;
    state_error(:,k+1)=s_e;
    mean_s_e=mean(state_error(:,1:k+1),2);  
if k<span
    mean_Q=mean(Qk(:,:,1:k+1),3);  
else
    mean_Q=mean(Qk(:,:,k-span+2:k+1),3); 
end
    pop1=sum(Xk_UKF_plus_store_smooth2(1:5,eff_index(k)),1);
    Xk_UKF_plus_store_smooth2(:,eff_index(k+1))=[pop1-sum(Xk_UKF_plus(1:4),1);Xk_UKF_plus];  
    R0_smooth2(1,k)=Xk_UKF_plus_store_smooth2(6,eff_index(k+1))/(Xk_UKF_plus_store_smooth2(8,eff_index(k+1))+Xk_UKF_plus_store_smooth2(9,eff_index(k+1)));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    xt0 = Xk_UKF_plus_store_smooth2(2:end,eff_index(K1));
    if R0_smooth2(1,K1-1)>1
    xt0(5)=mean(Xk_UKF_plus_store_smooth2([6],eff_index(1:K1)),2);
    end
    x2=[];
    for i=1:last-eff_index(K1)
    [xx2,~,~]=UKF_predict(xt0,Pk_UKF_plus,i*mean_Q,[eff_index(K1):1/5:eff_index(K1)+i],pop1,1,mean_s_e);
    x2=[x2,[round(xx2(1:4));xx2(5:8)]];
    end 
    Xk_UKF_plus_store_smooth2(:,eff_index(K1)+1:end)=[sum(Xk_UKF_plus_store_smooth2(1:5,eff_index(K1)),1)-sum(x2(1:4,:),1);x2];  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot -- collected data reported by NHC or Tencent news
figure()
hold on
plot(eff_index,Xk1(1,:),'-o','Markersize',1)
plot(eff_index,Xk1(1,:)-Xk1(2,:)-Xk1(3,:),'-*','Markersize',1)
plot(eff_index,Xk1(2,:),'-^','Markersize',1)
plot(eff_index,Xk1(3,:),'-v','Markersize',1)
set(gca,'XTick',1:30:eff_index(end)+1);
dateaxis('x',6,initial_date-1)
set(gca,'XTickLabelRotation',45)
axis([0 eff_index(end)+1 0 1.2*max(Xk1(1,:))])
xlabel('Date')
xlabel('Number')
legend('Cumulative infections' , 'Current infections' , 'Recovery cases' , 'Death cases' )
legend('Location','northwest')
title('Reported data')
%% plot results
R00=Xk_UKF_plus_store_smooth2(6,1)/(Xk_UKF_plus_store_smooth2(8,1)+Xk_UKF_plus_store_smooth2(9,1)) ;
R0_smooth2=[R00,R0_smooth2];
mean_R0=mean(R0_smooth2);
mean_std_R0=mean(std_R0);
R0_CI=[mean_R0;mean_R0-2*mean_std_R0;mean_R0+2*mean_std_R0];
figure()
hold on
plot(1:K1,R0_smooth2,'r-','Linewidth',1.5)
plot(1:K1,mean_R0*ones(1,K1),'b--','Linewidth',1.5)
set(gca,'XTick',1:30:size(R0_smooth2,2));
dateaxis('x',6,initial_date)
set(gca,'XTickLabelRotation',45)
legend('R0(t)','The mean of R0(t)')
legend('Location','northwest')
std_para=[std(Xk_UKF_plus_store_smooth2(6,eff_index)),std(Xk_UKF_plus_store_smooth2(7,eff_index)),std(Xk_UKF_plus_store_smooth2(8,1:55)),std(Xk_UKF_plus_store_smooth2(9,eff_index))];
mean_parameter=repmat([mean(Xk_UKF_plus_store_smooth2(6:9,eff_index),2)]',3,1)+[zeros(1,4);-2*std_para;2*std_para];
mean_parameter=[mean_parameter(:,1:2),mean_parameter(:,3)+mean_parameter(:,4)];
mean_parameter(find(mean_parameter<0))=0;
R0_result=['The basic reproductive number R0 of GEC is:'];
disp(R0_result);
disp(num2str(mean_R0));
end
end
