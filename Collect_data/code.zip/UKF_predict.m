function   [Xk_plus_f,tr1,tr2]=UKF_predict(Xk_UKF_minus,Cov_UKF_minus,Qk,tspan,pop,m,state_error)
dim_x=8;dim_y=3;N=dim_x;num_s=(2*N+1);
%% Set selection of Sigma Points
Xk_minus=zeros(dim_x,num_s);
Xk_minus_a=Xk_UKF_minus;
Xk_minus(:,N+1)=Xk_minus_a;
W0=0.1;
W=((1-W0)/(2*N))*ones(1,num_s); W(1,N+1)=W0; 
temp_s0=chol(N/(1-W(1,N+1))*Cov_UKF_minus);
temp_s=temp_s0';
for j=1:N
    Xk_minus(:,j)=Xk_minus_a-temp_s(:,j);
    Xk_minus(:,j+N+1)=Xk_minus_a+temp_s(:,j);
end
%% Time update
Xk_plus_fj=zeros(dim_x,num_s);
Xk_plus_f=zeros(dim_x,1); Zk_minus_f=zeros(dim_y,1);
for j=1:num_s
xt0 = Xk_minus(1:8,j);
f = @(t,seir) [m*seir(5)*(pop-seir(1)-seir(2)-seir(3)-seir(4))*seir(1)/pop - seir(6)*seir(1); seir(6)*seir(1)-(seir(7)+seir(8))*seir(2);seir(7)*seir(2);seir(8)*seir(2);0;0;0;0];
[~,value] = ode45(f,tspan,xt0);
Xk_plus_fj(:,j)=value(end,:)'+state_error;
Xk_plus_f= Xk_plus_f+W(j)*Xk_plus_fj(:,j);
end
Xk_plus_f=[round(Xk_plus_f(1:4));Xk_plus_f(5:8)];
Pk_plus_f=Qk;
for j=1:num_s
Pk_plus_f=Pk_plus_f+W(j)*(Xk_plus_fj(:,j)-Xk_plus_f)*(Xk_plus_fj(:,j)-Xk_plus_f)';
end
Pk_plus_f=(Pk_plus_f+Pk_plus_f')/2;
tr1=sqrt(trace(Pk_plus_f(2:4,2:4)));
tr2=sqrt(trace(Pk_plus_f(2,2)));
ind=Xk_plus_f(3:4)-Xk_UKF_minus(3:4);
ind_b=find(ind<0);
Xk_plus_f(ind_b+2,:)=Xk_UKF_minus(ind_b+2,:);
err1=sum(Xk_plus_f(2:4),1)-sum(Xk_UKF_minus(2:4),1);
if err1<0
Xk_plus_f(2)=Xk_plus_f(2)-err1;
end
err2=sum(Xk_plus_f(1:4),1)-sum(Xk_UKF_minus(1:4),1);
if err2<0
Xk_plus_f(1)=Xk_plus_f(1)-err2;
end
if Xk_plus_f(5)<0
    Xk_plus_f(5)=0.0001;
end
if Xk_plus_f(6)<1/30
    Xk_plus_f(6)=1/30;
end
end

