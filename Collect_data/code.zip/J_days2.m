function [estimate_last,x_last,cum_inf_last,err_last,x_est_last] = J_days2(Xk_UKF_plus0,Xk1,Q,R,Pop,J,eff_index,time)
K1=size(Xk1,2);
eff_index=[eff_index,eff_index(end)+1:eff_index(end)+J];
Zk_sensor=Xk1;
span=3;
n=length(Pop);
pre_day=J;
true_IRD=[Xk1(1,:)-Xk1(2,:)-Xk1(3,:);Xk1(2,:);Xk1(3,:)];
estimate=[];
xx=[];
cum_inf=[];
min_M=[];
for i=1
Xk_UKF_plus01=Xk_UKF_plus0;
Xk_UKF_plus01(5)=Xk_UKF_plus0(5);
err=[];
x_est=[];
cum1=[];
hwait=waitbar(0,'Compute N, please wait>>>>>>>>');
for i=1:n
[x_ini,cum]=smooth_filter(Xk_UKF_plus01,Xk1(:,1:time),Q,R,Pop(i),1,1,eff_index(1:size(Xk1(:,1:time),2)));
x_est=[x_est,x_ini];
cum1=[cum1;cum];
predict=cell(K1-1,1);
predict_cov_trace=zeros(J,K1-1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Xk_UKF_plus_store_smooth2=zeros(9,K1+J);
Xk_UKF_plus_store_smooth2(:,1)=[Pop(i)-sum(x_ini(1:4));x_ini];
Qk=zeros(8,8,K1);
Qk(:,:,1)=Q;
mean_Q=Q;
sta=[];
state_error=zeros(8,K1);
mean_s_e=state_error(:,1);
Pk_UKF_plus=1*Q;
pop1=Pop(i);
Xk_UKF_plus=x_ini;
aaaa=[];
aaaa=[aaaa,sqrt(trace(Pk_UKF_plus(2,2)))];
for k=1:K1-1
    m_es=1;
    [Xk_UKF_plus,Pk_UKF_plus,Q1,s_e]=UKF_control1(Xk_UKF_plus,Pk_UKF_plus,Zk_sensor(:,k+1),R,Q,[eff_index(k):1/10:eff_index(k+1)],pop1,m_es,mean_s_e);
    Qk(:,:,k+1)=Q1;
    state_error(:,k+1)=s_e;
    mean_s_e=mean(state_error(:,1:k+1),2);  
if k<span
    mean_Q=mean(Qk(:,:,1:k+1),3);  
else
    mean_Q=mean(Qk(:,:,k-span+2:k+1),3); 
end
    sta=[sta,trace(mean_Q(2:4,2:4))];
    aaaa=[aaaa,sqrt(trace(Pk_UKF_plus(2,2)))];
    pop1=sum(Xk_UKF_plus_store_smooth2(1:5,eff_index(k)),1);
    Xk_UKF_plus_store_smooth2(:,eff_index(k+1))=[pop1-sum(Xk_UKF_plus(1:4),1);Xk_UKF_plus];  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    xt1 = Xk_UKF_plus_store_smooth2(2:end,eff_index(k+1));
    x=[];
    tr=[];
    Pk_UKF_plus1=Pk_UKF_plus;
    for j=1:pre_day
    [xt0,trtr]=UKF_predict(xt1,Pk_UKF_plus1,j*mean_Q,[eff_index(k+1):1/5:eff_index(k+1+j)],pop1,1,mean_s_e);
    x=[x,xt0];
    tr=[tr;trtr];
    end
    value=x(2:4,:);
    predict{k,1}=value;
    predict_cov_trace(:,k)=tr.^2;
end
all_err=[];
for p=1:K1-2
    if p+1+pre_day<=K1
     pre_cum_kplus=[abs(sum((predict{p,1}-true_IRD(:,p+2:p+pre_day+1)),1))./Xk1(1,p+2:p+pre_day+1)]';
    else
     pre_cum_kplus=[[abs(sum((predict{p,1}(:,1:K1-p-1)-true_IRD(:,p+2:K1)),1))./Xk1(1,p+2:K1)]';0*predict_cov_trace(K1-p:end,p)]; 
    end
     all_err=[all_err,pre_cum_kplus];
end

mean_all_err=zeros(pre_day,1);
for kk=1:pre_day
mean_all_err(kk,1)=mean(all_err(kk,1:end+1-kk),2);
end       
err=[err,round(100000000*mean(mean_all_err,1))];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
str=['Runing; ',num2str(i/n*100),'%'];
waitbar(i/n,hwait,str);
end
    close(hwait)
    [M,min_N_ind]=min(err);
    min_M=[min_M,M];
    estimate=[estimate,Pop(min_N_ind)];
    xx=[xx,x_est(:,min_N_ind)];
    cum_inf=[cum_inf;cum1(min_N_ind,:)];
end
    [M1,min_N_ind1]=min(min_M);
    estimate_last=estimate(min_N_ind1);
    x_last=xx(:,min_N_ind1);
    cum_inf_last=cum_inf(min_N_ind1,:);
end
