function [ini,cum] = smooth_filter(Xk_UKF_plus,Xk,Q,R,Pop,m,time,time_index)
K=size(Xk,2);
Xk_UKF_plus_store0=zeros(9,K);
Zk_sensor=Xk;
Xk_UKF_plus_store0(:,1)=[Pop-sum(Xk_UKF_plus(1:4,1));Xk_UKF_plus]; 
Pk_UKF_plus=Q;
pop1=Pop;
for t=1:time
for k=1:K-1
    [Xk_UKF_plus,Pk_UKF_plus]=UKF_control(Xk_UKF_plus,Pk_UKF_plus,Zk_sensor(:,k+1),R,Q,[time_index(k):1/10:time_index(k+1)],pop1,m);
    pop1=sum(Xk_UKF_plus_store0(1:5,k),1);
    Xk_UKF_plus_store0(:,k+1)=[pop1-sum(Xk_UKF_plus(1:4),1);Xk_UKF_plus]; 
end
Xk_UKF_plus_store0_smooth=zeros(9,K);
Xk_UKF_plus_store0_smooth(:,K)=Xk_UKF_plus_store0(:,K);
Pk_UKF_plus=1.5*Q;
for k=K-1:-1:1
[Xk_UKF_plus,Pk_UKF_plus]=UKF_control(Xk_UKF_plus,Pk_UKF_plus,Zk_sensor(:,k),R,1.5*Q,[time_index(k+1):-1/10:time_index(k)],pop1,m);
    pop1=sum(Xk_UKF_plus_store0_smooth(1:5,k+1),1);
    Xk_UKF_plus_store0_smooth(:,k)=[pop1-sum(Xk_UKF_plus(1:4),1);Xk_UKF_plus];    
end
Pk_UKF_plus=Q;
Xk_UKF_plus_store0(:,1)=Xk_UKF_plus_store0_smooth(:,1);
end
ini=Xk_UKF_plus_store0_smooth(2:end,1);
cum=sum(Xk_UKF_plus_store0_smooth(2:5,:),1);
end


